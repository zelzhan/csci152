package Library;

public class DVD extends Library {
    boolean shiny;

    /**
     * Default constructor
     */
    public DVD(){
        super();
        this.shiny = false;
    }

    /**
     * Constructor
     * @param amount amount of borrowed items
     * @param borrowed are these items borrowed?
     * @param shiny Is this DvD shiny?
     */
    public DVD(int amount, boolean borrowed, boolean shiny){
        super(amount, borrowed);
        this.shiny = shiny;
    }

    public String toString() {
        return "This is shiny DVD: " + this.shiny;
    }
}
