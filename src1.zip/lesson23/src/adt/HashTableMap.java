package adt;

/**
 * @param <K>
 * @param <V>
 */
public interface HashTableMap<K, V> extends Map<K, V>, HashTableStats {
    // Nothing new to implement
}