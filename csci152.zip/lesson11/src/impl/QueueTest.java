package impl;
import impl.Node;
import impl.LinkedListQueue;
import adt.Queue;

public class QueueTest {
    public static void main(String[] args) {
        Queue<Character> que = new LinkedListQueue<Character>();
    }
}
